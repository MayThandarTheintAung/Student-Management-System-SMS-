package com.team3.sms.enums;

public enum Role {
	ISSTUDENT, ISFACULTY, ISADMIN
}
