package com.team3.sms.enums;

public enum LeaveStatus {
	ISPENDING, ISAPPROVED, ISREJECTED;
}
