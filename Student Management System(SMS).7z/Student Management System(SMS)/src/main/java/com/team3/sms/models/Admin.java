package com.team3.sms.models;

import javax.persistence.Entity;

@Entity
public class Admin extends User {

}
